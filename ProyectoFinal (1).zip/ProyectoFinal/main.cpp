#include <iostream>
#include "Juego.h"

using namespace sf;
using namespace std;

int main(){
    Juego juego;
    juego.CorrerJuego();
    return EXIT_FAILURE;
}
